
CANTFLOW — PACCHETTO PER INSTALLER AUTOMATICO (NO COMPILAZIONE SUL TUO PC)

OBIETTIVO
Ottieni un file di installazione Windows (.exe) pronto all'uso, generato in cloud da GitHub Actions.

PASSI
1) Crea un repository GitHub vuoto (es. CantFlow).
2) Copia dentro TUTTO il progetto CantFlow (cartella con .csproj, cartelle Views, Models, ViewModels, Data, ecc.).
   Aggiungi anche questa cartella "Installer" e il file ".github/workflows/build-installer.yml".
3) Fai commit e push su GitHub.
4) Nella pagina del repo, vai su "Actions" e lancia manualmente il workflow "Build CantFlow Installer"
   (oppure crea un tag v1.0.0 per farlo partire automaticamente).
5) A fine job, scarica l'artifact "CantFlowInstaller" — dentro troverai:
   - CantFlowInstaller.exe  (installer tradizionale)
   - CantFlow.exe (eseguibile self-contained; funziona anche senza .NET)

NOTE
- L'installer si basa su Inno Setup e crea collegamenti Start Menu e (opzionale) desktop.
- Se vuoi cambiare nome app/versione, modifica Installer/CantFlow.iss (sezione [Setup]).
- Il workflow usa Windows runner, .NET 8, pubblicazione self-contained win-x64 single-file.
